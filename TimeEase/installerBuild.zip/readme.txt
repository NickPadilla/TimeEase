Go-Time! Readme
=============

Go-Time! is a time tracking software that integrates with FreshBooks
Billing Software(www.freshbooks.com). 

It is fully cross-platform and is easy to install and use. As such,
it is an alternative to the default FreshBooks Time Tracker.  In the
future it will provide many more functions, just started with the most
basic one, Time Tracking. 

Go-Time! only requires an installed 1.6.x Java Runtime Environment to run
and install.  If there are any problems installing or running please
feel free to comment at www.monstersoftwarellc.com/gotime.

For more Go-Time! information please select 'Help' from the Go-Time! menu. 
Then select 'Help Contents'. 

Licensing
=========

Go-Time! is published under the terms of presented in the next screen.

Community
=========

Go-Time! is powered by Monster Software LLC, vist me at www.monstersoftwarellc.com!

* Web site: <http://monstersoftwarellc.com/gotime/>
* Email bugs to: <monstersoftwarellc@tickets.assembla.com>
