#!/usr/bin/env bash

# This is the installer script that will create all needed installer information
# for Go-Time!.
 
cd /home/nicholas/IzPack/bin
sh compile ../linuxGo/Linux.gtk.x86_64-GoTime-Installer.xml -b ../linuxGo
sh compile ../linuxGo/Linux.gtk.x86-GoTime-Installer.xml -b ../linuxGo
sh compile ../windowsGo/Win32.x86_64-GoTime-Installer.xml -b ../windowsGo
sh compile ../windowsGo/Win32.x86-GoTime-Installer.xml -b ../windowsGo
sh compile ../macGo/Macosx.carbon.x86-GoTime-Installer.xml -b ../macGo
sh compile ../macGo/Macosx.cocoa.x86_64-GoTime-Installer.xml -b ../macGo
sh compile ../macGo/Macosx.cocoa.x86-GoTime-Installer.xml -b ../macGo
cd ../utils/wrappers/izpack2app
python izpack2app.py ../../../macGo/Macosx.carbon.x86-GoTime-Installer.jar ../../../macGo/Macosx.carbon.x86-GoTime-Installer.app
python izpack2app.py ../../../macGo/Macosx.cocoa.x86_64-GoTime-Installer.jar ../../../macGo/Macosx.cocoa.x86_64-GoTime-Installer.app
python izpack2app.py ../../../macGo/Macosx.cocoa.x86-GoTime-Installer.jar ../../../macGo/Macosx.cocoa.x86-GoTime-Installer.app
